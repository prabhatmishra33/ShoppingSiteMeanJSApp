export class Ingredients{
    //public itemName:String
    //public itemDescp:String
    ///public itemPrice:Number

    constructor(public itemName:string,public itemDescp:string,public itemPrice:number){
        //this.itemName = itemName
        //this.itemDescp = itemDescp
        //this.itemPrice = itemPrice
    }
}