import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';

import { ShoppingListComponent } from './shopping-list/shopping-list.component';
import { ShoppingEditComponent } from './shopping-list/shopping-edit/shopping-edit.component';
import { AppRouter } from './app.route';

//import { HttpModule } from '@angular/http';

import { HttpClientModule } from '@angular/common/http'

import { SharedModule } from './shared/shared.module';
import { AuthModule } from './auth/auth.module';
import { ShopModule } from './shopping-list/shoping.module';
import { CoreModule } from './core/core.module';
 
@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    AppRouter,
    HttpClientModule,
    //HttpModule,
    SharedModule,
    AuthModule,
    ShopModule,
    CoreModule
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
